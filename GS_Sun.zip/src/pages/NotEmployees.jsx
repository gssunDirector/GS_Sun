export const NotEmployees = () => {
    return (
        <div className="flex h-full w-full justify-center items-center">Ви не є співробітником</div>
    )
}